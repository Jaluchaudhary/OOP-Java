class BusTour {
    private String tourId;
    private String busName;
    private double ticketCost;
    private int seatsSold;
    private int sellTicket;
    
    // Constructor

    public BusTour(String tourId, String busName, double ticketCost, int sellTicket) {
        this.tourId = tourId;
        this.busName = busName;
        this.ticketCost = ticketCost;
        this.sellTicket = sellTicket;
        this.seatsSold = 0; // Initially, no seats are sold
    }

    // Accessors 

    public String getTourId() {
        return tourId;
    }

    public String getBusName() {
        return busName;
    }

    public double getTicketCost() {
        return ticketCost;
    }

    public int getSeatsSold() {
        return seatsSold;
    }
    public int getsellTicket() {
        return sellTicket;
    }
    
    //Mutators
    
    public void setTourId(String tourId) {
        this.tourId = tourId;
    }

    public void setBusName(String busName) {
        this.busName = busName;
    }

    public void setTicketCost(double ticketCost) {
        this.ticketCost = ticketCost;
    }

    public void setSeatsSold(int seatsSold) {
        this.seatsSold = seatsSold;
    }
    public void sellTicket (int sellTicket) {
        this.sellTicket = sellTicket;
    }

    // Special purpose Method 

    public String toString() {
        return "Tour ID: " + tourId + ", Bus Name: " + busName + ", Ticket Cost: $" + ticketCost + ", Seats Sold: " + seatsSold + "sell Ticket:" 
        + sellTicket;
    }
}
