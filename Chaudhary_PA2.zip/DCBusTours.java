
import javax.swing.JOptionPane;

public class DCBusTours {
        
    private static final int MAX_BUS_TOURS = 15; // Maximum number of bus tours allowed
    private BusTour[] tours; // Array to store bus tours
    private int numTours; // Number of currently existing bus tours


 // Constructor to initialize the array 

    public DCBusTours() {
        tours = new BusTour[MAX_BUS_TOURS];
        numTours = 0;
    }

 // Method to create a new bus tour
    public void createBusTour(String tourId, String busName, double ticketCost, int sellTicket) {
        if (numTours < MAX_BUS_TOURS) {
            BusTour newTour = new BusTour(tourId, busName, ticketCost, sellTicket);
            tours[numTours++] = newTour;
            JOptionPane.showMessageDialog(null, "Bus Tour created successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Maximum number of bus tours");
        }
    }

// Method to remove bus tour

    public void removeBusTour(String tourId) {
        int index = findTourIndex(tourId);
        if (index != -1) {
            for (int i = index; i < numTours - 1; i++) {
                tours[i] = tours[i + 1];
            }
            numTours--;

            JOptionPane.showMessageDialog(null, "Bus Tour removed successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Bus Tour not found!");
        }
    }

    // Method to sell tour tickets for a bus tour
    public void sellTourTicket(String tourId, int numTickets) {
        int index = findTourIndex(tourId);
        if (index != -1) {

            BusTour tour = tours[index];
            int availableSeats = tour.getsellTicket() - tour.getSeatsSold();
            if (numTickets <= availableSeats) {
                tour.setSeatsSold(tour.getSeatsSold() + numTickets);
                JOptionPane.showMessageDialog(null, numTickets + " tickets sold successfully for Tour ID: " + tourId);
            } else {
                JOptionPane.showMessageDialog(null, "Not enough seats available for Tour ID: " + tourId);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Bus Tour not found!");
        }
    }

// Method to display for all bus tours

    public void displayBusTours() {
        StringBuilder report = new StringBuilder("Bus Tours Information:\n");
        double totalEarnings = 0;
        for (int i = 0; i < numTours; i++) {
            BusTour tour = tours[i];
            double earnings = tour.getTicketCost() * tour.getSeatsSold();
            report.append(tour.toString()).append("\n");
            report.append("Earnings for Tour ID ").append(tour.getTourId()).append(": $").append(earnings).append("\n\n");
            totalEarnings += earnings;
        }

        report.append("Total number of bus tours: ").append(numTours).append("\n");
       
        report.append("Total earnings from all bus tours: $").append(totalEarnings);
        JOptionPane.showMessageDialog(null, report.toString(), "Bus Tours Report", JOptionPane.INFORMATION_MESSAGE);
    }


    // method to find the index of a bus tour in the array
   
    private int findTourIndex(String tourId) {
        for (int i = 0; i < numTours; i++) {
            if (tours[i].getTourId().equals(tourId)) {
                return i;
            }
        }
        return -1;
    }

    // Main method to run the program
    
    public static void main(String[] args) {
        DCBusTours aDcBusTours = new DCBusTours();
        int choice;
        do {

     // Display menu options and get user choice

            choice = Integer.parseInt(JOptionPane.showInputDialog("Choose one of the following option:\n" + "1. Create Bus Tour\n" + "2. Remove Bus Tour\n" +
            "3. Sell Tour Ticket\n" + "4. Display Bus Tours\n" + "5. Exit"));

            switch (choice) {

               
                case 1:

     // prompt user for the tour details and new bus tour

                    String tourId = JOptionPane.showInputDialog("Enter Tour ID:");
                    String busName = JOptionPane.showInputDialog("Enter Bus Name:");
                    double ticketCost = Double.parseDouble(JOptionPane.showInputDialog("Enter Ticket Cost:"));
                    int sellTicket = Integer.parseInt(JOptionPane.showInputDialog("Enter Sellable Tickets:"));
                    aDcBusTours.createBusTour(tourId, busName, ticketCost, sellTicket);
                    break;

                    case 2:

     // Prompt user for tour ID to remove and remove the bus tour

                    String removeTourId = JOptionPane.showInputDialog("Enter Tour ID to remove:");
                    aDcBusTours.removeBusTour(removeTourId);
                    break;

                case 3:

     // Prompt user for tour ID and number of tickets to sell, then sell the tickets

                    String sellTourId = JOptionPane.showInputDialog("Enter Tour ID to sell ticket:");
                    int numTickets = Integer.parseInt(JOptionPane.showInputDialog("Enter number of tickets to sell:"));
                    aDcBusTours.sellTourTicket(sellTourId, numTickets);
                    break;
                case 4:

    // Display information about all bus tours

                    aDcBusTours.displayBusTours();
                    break;

                case 5:

               
                    JOptionPane.showMessageDialog(null, "Exiting program...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice!"); // Show error message for invalid choice
            }
        } while (choice != 5);


        DCBusTours aBusTours = new DCBusTours();
        
        aBusTours.displayBusTours();
        

    }
}


