    public class Life extends Policy {
        private String beneficiaryName;
        private double faceValue;

        // Constructor
        public Life(String policyNumber, String policyOwner, double yearlyPremium, 
                String beneficiaryName, double faceValue) {
            super(policyNumber, policyOwner, yearlyPremium);
            setBeneficiaryName(beneficiaryName);
            setFaceValue(faceValue);
        }

        // Accessors 
        public String getBeneficiaryName() {
            return beneficiaryName;
        }

        public double getFaceValue() {
            return faceValue;
        }

        // Mutators 
        public void setBeneficiaryName(String beneficiaryName) {
            if (beneficiaryName != null && !beneficiaryName.trim().isEmpty()) {
                this.beneficiaryName = beneficiaryName;
            } else {
                throw new IllegalArgumentException("Beneficiary name cannot be blank.");
            }
        }

        public void setFaceValue(double faceValue) {
            if (faceValue > 0) {
                this.faceValue = faceValue;
            } else {
                throw new IllegalArgumentException("Face value must be positive.");
            }
        }
      //Special Purpose Method
        public String toString() {
            return "No: " + getPolicyNumber() + ", Insured By: " + getPolicyOwner() + ", Premium: $" 
            + String.format("%.2f", getYearlyPremium()) + " (Life) - Beneficiary: " + beneficiaryName 
            + ", Amount: $" + String.format("%.2f", faceValue);
        }
    }
