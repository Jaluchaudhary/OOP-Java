        public class Automobile extends Policy {
        
            private String vehicleVIN;
            private String make;
            private String model;
            private static final int VIN_LENGTH = 12;// Static Variables
            private static final char[] INVALID_VIN_CHARS = {'O', 'I', 'Q'};// invalid for VIN

            // Constructor
            public Automobile(String policyNumber, String policyOwner, 
                    double yearlyPremium, String vehicleVIN, String make, String model) {
                super(policyNumber, policyOwner, yearlyPremium);
                setVehicleID(vehicleVIN);
                setMake(make);
                setModel(model);
            }

            // Accessors 
            public String getVehicleVIN() {
                return vehicleVIN;
            }

            public String getMake() {
                return make;
            }

            public String getModel() {
                return model;
            }

            // Mutators with validation
            public void setVehicleID(String vehicleVIN) {
                if (isValidVIN(vehicleVIN)) {
                    this.vehicleVIN = vehicleVIN;
                } else {
                    throw new IllegalArgumentException("Invalid vehicle VIN.");
                }
            }

            public void setMake(String make) {
                if (make != null && !make.trim().isEmpty()) {
                    this.make = make;
                } else {
                    throw new IllegalArgumentException("Make cannot be blank.");
                }
            }

            public void setModel(String model) {
                if (model != null && !model.trim().isEmpty()) {
                    this.model = model;
                } else {
                    throw new IllegalArgumentException("Model cannot be blank.");
                }
            }

            // Validation Methods with boolean
            private boolean isValidVIN(String vin) {
                if (vin.length() != VIN_LENGTH) return false;
                for (char c : INVALID_VIN_CHARS) {
                    if (vin.indexOf(c) != -1) return false;
                }
                return true;
            }

            //Special Purpose Method
            public String toString() {
                return "No: " + getPolicyNumber() + ", Insured By: "
                + getPolicyOwner() + ", Premium: $" + String.format("%.2f", getYearlyPremium()) + " (Auto) - VIN: "
                + vehicleVIN + ", Make: " + make + ", Model: " + model;
            }
        }
