
import javax.swing.JOptionPane;

public class policies {
    private static final int MAX_POLICIES = 100;
    private static Policy[] policies = new Policy[MAX_POLICIES];
    private static int policyCount = 0;

            public static void main(String[] args) {
                boolean exit = false;
                while (!exit) {
                    String choice = JOptionPane.showInputDialog("1. Add Policy\n2. Remove Policy\n3. View Policies\n4. Quit");
                    switch (choice) {
                        case "1":
                            addPolicy();
                            break;
                        case "2":
                            removePolicy();
                            break;
                        case "3":
                            viewPolicies();
                            break;
                        case "4":
                            JOptionPane.showMessageDialog(null, "Thank you for using the solution.");
                            exit = true;
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid choice, please try again.");
                    }
                }
            }

    private static void addPolicy() {
        if (policyCount >= MAX_POLICIES) {
            JOptionPane.showMessageDialog(null, "Policy limit reached.");
            return;
        }

        String type = JOptionPane.showInputDialog("Enter policy type (auto/home/life):");
        try {
            String policyNumber = JOptionPane.showInputDialog("Enter policy number:");
            String policyOwner = JOptionPane.showInputDialog("Enter policy owner:");
            double yearlyPremium = Double.parseDouble(JOptionPane.showInputDialog("Enter yearly premium:"));

            Policy newPolicy;
            switch (type.toLowerCase()) {
                case "auto":
                    String vehicleID = JOptionPane.showInputDialog("Enter vehicle VIN:");
                    String make = JOptionPane.showInputDialog("Enter make:");
                    String model = JOptionPane.showInputDialog("Enter model:");
            
                    newPolicy = new Automobile(policyNumber, policyOwner, yearlyPremium, vehicleID, make, model);
                    break;
                
                    
                    case "home":
                    String streetAddress = JOptionPane.showInputDialog("Enter street address:");
                    int yearBuilt = Integer.parseInt(JOptionPane.showInputDialog("Enter year built:"));
                    double deductible = Double.parseDouble(JOptionPane.showInputDialog("Enter deductible:"));
                    
                    newPolicy = new Home(policyNumber, policyOwner, yearlyPremium, streetAddress, yearBuilt, deductible);
                    break;
                case "life":
                    String beneficiaryName = JOptionPane.showInputDialog("Enter beneficiary name:");
                    
                    double faceValue = Double.parseDouble(JOptionPane.showInputDialog("Enter face value:"));
                    
                    newPolicy = new Life(policyNumber, policyOwner, yearlyPremium, beneficiaryName, faceValue);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid policy type.");
                    return;
            }
            policies[policyCount++] = newPolicy;
           
            JOptionPane.showMessageDialog(null, "Policy added successfully.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error adding policy: " + e.getMessage());
        }
    }

    private static void removePolicy() {
        String policyNumber = JOptionPane.showInputDialog("Enter policy number to remove:");
        for (int i = 0; i < policyCount; i++) {
            if (policies[i].getPolicyNumber().equals(policyNumber)) {
                policies[i] = policies[--policyCount];
                policies[policyCount] = null;
                JOptionPane.showMessageDialog(null, "Policy removed successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Policy not found.");
    }

    private static void viewPolicies() {
        if (policyCount == 0) {
            JOptionPane.showMessageDialog(null, "No policies available.");
            return;
        }

        String result = "Policies:\n";
        for (int i = 0; i < policyCount; i++) {
            result += policies[i].toString() + "\n\n";
        }
        JOptionPane.showMessageDialog(null, result);
    }
}
