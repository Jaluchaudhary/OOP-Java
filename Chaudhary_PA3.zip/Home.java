        public class Home extends Policy {

            private String streetAddress;
            private int yearBuilt;
            private double deductible;

            // Constructor
            public Home(String policyNum, String policyOwner, double yearlyPremium, String streetAddress, int yearBuilt, 
            double deductible) {
                super(policyNum, policyOwner, yearlyPremium);
                setStreetAddress(streetAddress);
                setYearBuilt(yearBuilt);
                setDeductible(deductible);
            }

            // Accessors
            public String getStreetAddress() {
                return streetAddress;
            }

            public int getYearBuilt() {
                return yearBuilt;
            }

            public double getDeductible() {
                return deductible;
            }

            // Mutators (Setters) with validation
            public void setStreetAddress(String streetAddress) {
                if (streetAddress != null && !streetAddress.trim().isEmpty()) {
                    this.streetAddress = streetAddress;
                } else {
                    throw new IllegalArgumentException("Street address cannot be blank.");
                }
            }

            public void setYearBuilt(int yearBuilt) {
                if (yearBuilt >= 1800 && yearBuilt <= 2022) {
                    this.yearBuilt = yearBuilt;
                } else {
                    throw new IllegalArgumentException("Year built must be between 1800 and 2022.");
                }
            }

            public void setDeductible(double deductible) {
                if (deductible > 0) {
                    this.deductible = deductible;
                } else {
                    throw new IllegalArgumentException("Deductible must be positive.");
                }
            }


            //Special Purpose Method
            public String toString() {
                return "No: " + getPolicyNumber() + ", Insured By: " + getPolicyOwner() + ", Premium: $"
                + String.format("%.2f", getYearlyPremium()) + " (Home) - Street Address: " 
                + streetAddress + ", Year Built: " + yearBuilt + ", Deductible: $" + String.format("%.2f", deductible);
            }
        }
