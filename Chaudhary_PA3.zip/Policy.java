    public abstract class Policy {
        
        private String policyNumber;
        private String policyOwner;
        private double yearlyPremium;
        private static final int POLICY_NUMBER_LENGTH = 10;
        
        // Constructor
        public Policy(String policyNo, String policyOwner, double yearlyPremium) {
            setPolicyNumber(policyNo);
            setPolicyOwner(policyOwner);
            setYearlyPremium(yearlyPremium);
        }

        // Accessors 
        public String getPolicyNumber() {
            return policyNumber;
        }

        public String getPolicyOwner() {
            return policyOwner;
        }

        public double getYearlyPremium() {
            return yearlyPremium;
        }

        // Mutators  with validation and exception handling
        public void setPolicyNumber(String policyNumber) {
            if (isValidPolicyNumber(policyNumber)) {
                this.policyNumber = policyNumber;
            } else {
                throw new IllegalArgumentException("Invalid policy number.");
            }
        }

        public void setPolicyOwner(String policyOwner) {
            if (policyOwner != null && !policyOwner.trim().isEmpty()) {
                this.policyOwner = policyOwner;
            } else {
                throw new IllegalArgumentException("Policy owner cannot be blank.");
            }
        }

        public void setYearlyPremium(double yearlyPremium) {
            if (yearlyPremium > 0) {
                this.yearlyPremium = yearlyPremium;
            } else {
                throw new IllegalArgumentException("Yearly premium must be positive.");
            }
        }

        // Validation Methods boolean
        private boolean isValidPolicyNumber(String policyNumber) {
            if (policyNumber.length() != POLICY_NUMBER_LENGTH) return false;
            if (!Character.isLetter(policyNumber.charAt(0))) return false;
            for (int i = 1; i < POLICY_NUMBER_LENGTH; i++) {
                if (!Character.isDigit(policyNumber.charAt(i))) return false;
            }
            return true;
        }

        //Special Purpose Method

    public String toString() {
        return "No: " + policyNumber + ", Insured By: " + policyOwner + ", Premium: $" + String.format("%,.2f", yearlyPremium);
    }

    }