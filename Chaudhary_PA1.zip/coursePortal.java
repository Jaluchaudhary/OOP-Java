
import javax.swing.JOptionPane;
// CoursePortal class is the main class that handles course registration and displays a summary.
 
public class coursePortal {

    public static void main(String[] args) {
        
        final int Total_Courses = 4;
        int total_Enrollment = 0;
        course largest_Enrollment = null;

        for (int i = 0; i < Total_Courses; i++) {
            try {
                course course = inputCourse();
                total_Enrollment += course.getCurrentEnrollment();
                
                if (largest_Enrollment == null || course.getCurrentEnrollment() > largest_Enrollment.getCurrentEnrollment()) {
                    largest_Enrollment = course;
                }
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
                i--; // Retry the current course entry
            }
        }

        printSummary(Total_Courses, total_Enrollment, largest_Enrollment);
    }

    
    //the user to input course details and creates a Course object.
     
    private static course inputCourse() {
        String courseNumber = JOptionPane.showInputDialog("Enter course ID:");
        String courseDescription = JOptionPane.showInputDialog("Enter course description:");
        double creditHour = Double.parseDouble(JOptionPane.showInputDialog("Enter credit hour:"));
        int currentEnrollment = Integer.parseInt(JOptionPane.showInputDialog("Enter current enrollment:"));

        return new course(courseNumber, courseDescription, creditHour, currentEnrollment);
    }

    // Prints a summary of the total number of courses, total enrollment, average enrollment, and course with the largest enrollment.
     
    private static void printSummary (int totalCourses, int totalEnrollment, course largestEnrollment) {
       
        double averageEnrollment = (double) totalEnrollment / totalCourses;
       
        String summary = "Total number of courses: " + totalCourses + "\n" + "Total enrollment: " + totalEnrollment + "\n" +
                        "Average enrollment: " + averageEnrollment + "\n";
                         
        if (largestEnrollment != null) {
            summary += "Course with the largest enrollment:\n" + largestEnrollment.toString();
        }

        JOptionPane.showMessageDialog(null, summary);
    }
}


   