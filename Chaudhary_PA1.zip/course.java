
public class course {
    // Instance variables
        private String courseNumber;
        private String courseDescription;
        private double creditHour;
        private int currentEnrollment;

            // Constructor to initialize a course with number and credit hour
            
            public course(String courseNumber, double creditHour) {
                if (creditHour > 4.0 || creditHour < 0) {
                    throw new IllegalArgumentException("Credit hours must be between 0 and 4.0");
                }
                this.courseNumber = courseNumber;
                this.creditHour = creditHour;
            }

            // Constructor to initialize a course with number, description, credit hour, and enrollment
            public course(String courseNumber, String courseDescription, double creditHour, int currentEnrollment) {
                this(courseNumber, creditHour);
                this.courseDescription = courseDescription;
                setCurrentEnrollment(currentEnrollment);
            }

    // Accessor () get method
    public String getCourseNumber() {
        return courseNumber;
    }
    public String getCourseDescription() {
        return courseDescription;
    }

    public double getCreditHour() {
        return creditHour;
    }

    public int getCurrentEnrollment() {
        return currentEnrollment;
    }

    public int getSeatsRemaining() {
        return 40 - currentEnrollment;
    }
                // Mutators () set Method
                public void setCourseNumber(String courseNumber) {
                    this.courseNumber = courseNumber;
                }

                public void setCourseDescription(String courseDescription) {
                    this.courseDescription = courseDescription;
                }

                public void setCreditHour(double creditHour) {
                    if (creditHour > 4.0 || creditHour < 0) {
                        throw new IllegalArgumentException("Credit hours must be between 0 and 4.0");
                    }
                    this.creditHour = creditHour;
                }

                public void setCurrentEnrollment(int currentEnrollment) {
                    if (currentEnrollment > 40 || currentEnrollment < 0) {
                        throw new IllegalArgumentException("Enrollment must be between 0 and 40");
                    }
                    this.currentEnrollment = currentEnrollment;
                }

    // Special Purpose Method
    public String toString() {
        return "Course Number: " + courseNumber + "\n" + "Course Description: " + courseDescription + "\n" +
         "Credit Hours: " + creditHour + "\n" + "Current Enrollment: " + currentEnrollment + "\n" +
               "Seats Remaining: " + getSeatsRemaining() + "\n";
    }
}
