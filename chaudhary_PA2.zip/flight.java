public class flight {
            
    private String Flightid;
    private String Flightroute;
    private double ticketCost;
    private int seatsSold;

    private static final int MAX_SEATS = 100;
    private static final int ID_LENGTH = 4;


    // Constructor 
    public flight(String id, String route, double ticketCost) {
        setId(id);
        setRoute(route);
        setTicketCost(ticketCost);
        this.seatsSold = 0;
    }
// A valid ID must be 4 characters long, with the first two characters being uppercase letters
// and the last two characters being digits

    private boolean isValidId(String id) {
        if (id.length() != ID_LENGTH) return false;
        if (!Character.isUpperCase(id.charAt(0)) || !Character.isUpperCase(id.charAt(1))) return false;
        if (!Character.isDigit(id.charAt(2)) || !Character.isDigit(id.charAt(3))) return false;
        return true;
    }

    // Accessor () get method
    public String getId() {
        return Flightid;
    }

    public String getRoute() {
        return Flightroute;
    }

    public double getTicketCost() {
        return ticketCost;
    }

    public int getSeatsSold() {
        return seatsSold;
    }

    public double getTotalEarnings() {
        return seatsSold * ticketCost;
    }

// Mutators () set Method must be throw the Exception
    public void setId(String id) {
        if (!isValidId(id)) {
            throw new IllegalArgumentException("Invalid flight ID");
        }
        this.Flightid = id;
    }

    public void setRoute(String route) {
        if (route == null || route.isEmpty()) {
            throw new IllegalArgumentException("Route cannot be null or empty");
        }
        this.Flightroute = route;
    }

    
    public void setTicketCost(double ticketCost) {
        if (ticketCost <= 0) {
            throw new IllegalArgumentException("Ticket cost must be positive");
        }
        this.ticketCost = ticketCost;
    }

    
    public void sellTicket() {
        if (seatsSold >= MAX_SEATS) {
            throw new IllegalStateException("No seats available");
        }
        seatsSold++;
    }

    
    //Special Purpose Method
    public String toString() {
        return Flightid + " | " + Flightroute + " | $" + ticketCost + " | " + seatsSold + " | $" + String.format
        ("%.2f", getTotalEarnings());
    }
}
