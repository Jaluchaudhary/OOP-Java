import javax.swing.JOptionPane;

public class PatriotFlights {
    private flight[] flights;  
    private int numFlights;
    private static final int MAX_FLIGHTS = 15; // Maximum number of flights allowed

     // Constructor to initialize the flights array and the number of flights
    public PatriotFlights() {
        flights = new flight[MAX_FLIGHTS];
        numFlights = 0;
    }
       // Method to create a new flight
    public void createFlight() {
        if (numFlights >= MAX_FLIGHTS) {
            JOptionPane.showMessageDialog(null, "Error: Maximum number of flights reached.");
            return;
        }

        String Flightid = JOptionPane.showInputDialog("Enter Flight ID:");
        String Flightroute = JOptionPane.showInputDialog("Enter Flight Route:");
        double ticketCost;

        try {
            ticketCost = Double.parseDouble(JOptionPane.showInputDialog("Enter Ticket Cost:"));
            flights[numFlights++] = new flight(Flightid, Flightroute, ticketCost);
            JOptionPane.showMessageDialog(null, "Flight created successfully.");
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Invalid ticket cost.");

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }


    // Method to remove an existing flight
    public void removeFlight() {
        String Flightid = JOptionPane.showInputDialog("Enter Flight ID to remove:");
        int index = findFlightIndex(Flightid);

        if (index == -1) {
            JOptionPane.showMessageDialog(null, "Error: Flight not found.");
            return;
        }
        // remaining flights left to fill

        for (int i = index; i < numFlights - 1; i++) {
            flights[i] = flights[i + 1];
        }
        flights[--numFlights] = null;
        JOptionPane.showMessageDialog(null, "Flight removed successfully.");
    }

    // Method to sell a ticket for a specified flight
    public void sellTicket() {
        String Flightid = JOptionPane.showInputDialog("Enter Flight ID to sell ticket:");
        int index = findFlightIndex(Flightid);

        if (index == -1) {
            JOptionPane.showMessageDialog(null, "Error: Flight not found.");
            return;
        }

        try {
            flights[index].sellTicket();
            JOptionPane.showMessageDialog(null, "Ticket sold successfully.");
        } catch (IllegalStateException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    // Method to display all flights
    public void displayFlights() {
        if (numFlights == 0) {
            JOptionPane.showMessageDialog(null, "No flights available.");
            return;
        }

    // Construct the display message
        String message = " Patriot Flights \n";
        message += "Flight ID | Flight Route | Ticket Cost | Ticket Sold | Total Earnings\n";

        for (int i = 0; i < numFlights; i++) {
            message += flights[i].toString() + "\n";
        }

        message += "Total Flights: " + numFlights + "\n";

        double totalEarnings = 0;
        for (int i = 0; i < numFlights; i++) {
            totalEarnings += flights[i].getTotalEarnings();
        }

        message += "Total Earnings: $" + String.format("%.2f", totalEarnings);
        JOptionPane.showMessageDialog(null, message);
    }

      // method to find the index of a flight by ID
    private int findFlightIndex(String id) {
        for (int i = 0; i < numFlights; i++) {
            if (flights[i].getId().equals(id)) {
                return i;
            }
        }
        return -1; // Flight not found
    }

    // Main method to run the PatriotFlights program
    public static void main(String[] args) {
        PatriotFlights manager = new PatriotFlights();
        String[] options = {"Create Flight", "Remove Flight", "Sell Flight Ticket", "Display Flights", "Exit"};
        int option;

        do {
            option = JOptionPane.showOptionDialog(null, "* Patriot Flights *\nChoose one of the following options:",
                    "Patriot Flights", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            switch (option) {
                case 0:
                    manager.createFlight();
                    break;
                case 1:
                    manager.removeFlight();
                    break;
                case 2:
                    manager.sellTicket();
                    break;
                case 3:
                    manager.displayFlights();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Exiting program.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        } while (option != 4);
    }
}