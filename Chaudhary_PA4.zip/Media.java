    
    public class Media extends LibraryItem {
        private String type;
        private int duration;

        // Constructor
        public Media(String isbn, String title, int totalCopies, String type, int duration) {
            super(isbn, title, totalCopies);
            this.type = type;
            this.duration = duration;
        }

        // Accessors
        public String getType() { 
            return type; }

        public int getDuration() {
            return duration; }

    // Special Purpose Method
        public String toString() {
            return "Media ISBN" + getIsbn() + ", Title" + getTitle() + ", Type" + type + ", Duration" + duration
                    + " mins, Total Copies" + getTotalCopies() + ", Available Copies" + getAvailableCopies() + "";
        }
    }
