
import javax.swing.JOptionPane;

public class LibraryManage {

    public static void main(String[] args) {
        // This is the library with the name, address and librarian
        Library library = new Library(" Fenwick ", " Fairfax, VA", "Christof Dough" );

        while (true) {
            // This is dispaly the menu with the differnt option
            String option = JOptionPane.showInputDialog(null,
                    "Choose one of the following option:\n1. Add Library Items\n2. Search Library Items\n3. Checkout Book\n4.ViewLibrary Information\n5.Quit",
                    "Library Management System", JOptionPane.QUESTION_MESSAGE);

            // This is perform the action based on the user choice
            switch (option) {
                case "1":
                    addLibraryItem(library);
                    break;
                case "2":
                    searchLibraryItem(library);
                    break;
                case "3":
                    checkoutBook(library);
                    break;
                case "4":
                    displayLibraryInformation(library);
                    break;
                case "5":
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please choose again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
   // this is the method which is add the item 
    public static void addLibraryItem(Library library) {
        try {
            // to choice of the option media or book itm type
            String type = JOptionPane.showInputDialog(null, "Enter item type (Book/Media):", "Add Library Item", JOptionPane.QUESTION_MESSAGE);
            if (type.equalsIgnoreCase("Book")) {

                // this is get details of the book users
                String isbn = JOptionPane.showInputDialog(null, "Enter ISBN:", "Add Book", JOptionPane.QUESTION_MESSAGE);
                String title = JOptionPane.showInputDialog(null, "Enter Title:", "Add Book", JOptionPane.QUESTION_MESSAGE);
                int totalCopies = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Total Copies:", "Add Book", JOptionPane.QUESTION_MESSAGE));
                String author = JOptionPane.showInputDialog(null, "Enter Author:", "Add Book", JOptionPane.QUESTION_MESSAGE);
                String edition = JOptionPane.showInputDialog(null, "Enter Edition:", "Add Book", JOptionPane.QUESTION_MESSAGE);
                int year = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Publishing Year (YYYY):", "Add Book", JOptionPane.QUESTION_MESSAGE));

                // this is a book object add to the library
                Book book = new Book(isbn, title, totalCopies, author, edition, year);
                library.addItem(book);

            } else if (type.equalsIgnoreCase("Media")) {

                //Get the details of the media item
                String isbn = JOptionPane.showInputDialog(null, "Enter ISBN:", "Add Disc Media", JOptionPane.QUESTION_MESSAGE);
                String title = JOptionPane.showInputDialog(null, "Enter Title:", "Add Disc Media", JOptionPane.QUESTION_MESSAGE);
                int totalCopies = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Total Copies:", "Add Disc Media", JOptionPane.QUESTION_MESSAGE));
                String discType = JOptionPane.showInputDialog(null, "Enter Type (CD/DVD/BLURAY):", "Add Disc Media", JOptionPane.QUESTION_MESSAGE);
                int duration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Duration (in minutes):", "Add Disc Media", JOptionPane.QUESTION_MESSAGE));
                
               // this is a media object add to the library
                Media Media = new Media(isbn, title, totalCopies, discType, duration);
                library.addItem(Media);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid item type. Please enter either 'Book' or 'Media'.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error adding item: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // the method search the library item
    public static void searchLibraryItem(Library library) {

         // option for the search by isbn or title
        String searchOption = JOptionPane.showInputDialog(null, "Search by:\n1. Title\n2. ISBN", "Search Library Item", JOptionPane.QUESTION_MESSAGE);

        LibraryItem item = null;
        if (searchOption.equals("1")) {

            // get the title for the item by title
            String title = JOptionPane.showInputDialog(null, "Enter Title:", "Search by Title", JOptionPane.QUESTION_MESSAGE);
            item = library.searchItemByTitle(title);
        } else if (searchOption.equals("2")) {

            // get the isbn for the item by isbn
            String isbn = JOptionPane.showInputDialog(null, "Enter ISBN:", "Search by ISBN", JOptionPane.QUESTION_MESSAGE);
            item = library.searchItemByIsbn(isbn);
        }

        // views the item if found if not then show an error message
        if (item != null) {
            JOptionPane.showMessageDialog(null, item.toString(), "Library Item Found", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Library Item not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // The method chechOut the book
    public static void checkoutBook(Library library) {
        String isbn = JOptionPane.showInputDialog(null, "Enter ISBN of the book to checkout:", "Checkout Book", JOptionPane.QUESTION_MESSAGE);
        LibraryItem item = library.searchItemByIsbn(isbn);

        if (item != null && item instanceof Book) {
            if (item.getAvailableCopies() > 0) {
                String holderId = JOptionPane.showInputDialog(null, "Enter GMU ID:", "Checkout Book", JOptionPane.QUESTION_MESSAGE);
                String dueDate = JOptionPane.showInputDialog(null, "Enter Due Date (MMDDYYYY):", "Checkout Book", JOptionPane.QUESTION_MESSAGE);

                item.setCheckoutHolderId(holderId);
                item.setDueDate(dueDate);
                item.getAvailableCopies();

                JOptionPane.showMessageDialog(null, "Book checked out successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No available copies to checkout.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Book not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

     // Method to display library information
    public static void displayLibraryInformation(Library library) {
        JOptionPane.showMessageDialog(null, library.toString(), "Library Information", JOptionPane.INFORMATION_MESSAGE);
    }
}
