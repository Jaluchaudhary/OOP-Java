
   public class Book extends LibraryItem {
      private String author;
      private String edition;
      private int publishingYear;

      // Constructor
      public Book(String isbn, String title, int totalCopies, String author, String edition, int publishingYear) {
         super(isbn, title, totalCopies);
         this.author = author;
         this.edition = edition;
         this.publishingYear = publishingYear;
      }

      // Accessors 
      public String getAuthor() { 
         return author; }

      public String getEdition() { 
         return edition; }
         
      public int getPublishingYear() {
         return publishingYear; }

      // Special Purpose Method
      public String toString() {
         return "Book ISBN" + getIsbn() + ", Title" + getTitle() + ", Author" + author + ", Edition" + edition
                  + ", Year" + publishingYear + ", Total Copies" + getTotalCopies() + ", Available Copies" + getAvailableCopies() +"";
      }
   }

