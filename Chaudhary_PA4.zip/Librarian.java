    
    public class Librarian {
        private String name;
        

        // Constructor
        public Librarian(String name) {
            this.name = name;
        
        }
        // Accessors 
        public String getName() { 
            return name; }

    // Special Purpose Method 
        public String toString() {
            return " " + name + "";
        }
    }
    
