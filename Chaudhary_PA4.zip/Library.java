
    public class Library {
        private String name;
        private String address;
        private String librarian;
        private LibraryItem[] items;
        private int itemCount;

        public static final int MAX_ITEMS = 6000;

        // Constructor
        public Library(String name, String address, String librarian) {
            this.name = name;
            this.address = address;
            this.librarian = librarian;
            this.items = new LibraryItem[MAX_ITEMS];
            this.itemCount = 0;
        }

        // Accessors
        public String getName() { 
            return name; }

        public String getAddress() {
            return address; }

        public String getLibrarian() { 
            return librarian; }

        public int getItemCount() { 
            return itemCount; }

        //mutators
        public void addItem(LibraryItem item) throws Exception {
            if (itemCount >= MAX_ITEMS) {
                throw new Exception("Maximum number of items reached.");
            }
            items[itemCount++] = item;
        }

        public LibraryItem searchItemByTitle(String title) {
            for (LibraryItem item : items) {
                if (item != null && item.getTitle().equalsIgnoreCase(title)) {
                    return item;
                }
            }
            return null;
        }

        public LibraryItem searchItemByIsbn(String isbn) {
            for (LibraryItem item : items) {
                if (item != null && item.getIsbn().equals(isbn)) {
                    return item;
                }
            }
            return null;
        }

        // Special Purpose Method
        public String toString() {
            String result = "Library Name:" + name + ", Address:" + address + ", Librarian:" + librarian + "\n";
            result += "Total Items: " + itemCount + "\n";
            for (LibraryItem item : items) {
                if (item != null) {
                    result += item.toString() + "\n";
                }
            }
            return result;
        }
    }
