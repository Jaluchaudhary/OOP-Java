    
    public abstract class LibraryItem {
        private String isbn;
        private String title;
        private int totalCopies;
        private int availableCopies;
        private String checkoutHolderId;
        private String dueDate;

        // Constructor
        public LibraryItem(String isbn, String title, int totalCopies) {
            this.isbn = isbn;
            this.title = title;
            this.totalCopies = totalCopies;
            this.availableCopies = totalCopies;
        }

        // Accessors 
        public String getIsbn() {
            return isbn; }

        public String getTitle() {
            return title; }

        public int getTotalCopies() { 
            return totalCopies; }

        public int getAvailableCopies() { 
            return availableCopies; }

        public String getCheckoutHolderId() { 
            return checkoutHolderId; }

        public String getDueDate() { 
            return dueDate; }

        // mutators
        public void setCheckoutHolderId(String checkoutHolderId) { 
            this.checkoutHolderId = checkoutHolderId; }
        
            public void setDueDate(String dueDate) { 
            this.dueDate = dueDate; }

    // Special Purpose Method
        public abstract String toString();
    }
